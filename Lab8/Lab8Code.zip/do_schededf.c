#include "kernel/system.h"

#include <minix/endpoint.h>

/*===========================================================================*
 *				do_schededf				     *
 *===========================================================================*/
PUBLIC int do_schededf(struct proc * caller, message * m_ptr)
{

  struct proc *rp;
  int proc_nr = 0;
  endpoint_t e_proc_nr;
  
  if(isokendpt(m_ptr->m1_i3, &proc_nr))
	return EINVAL;
  rp = proc_addr(proc_nr);
  rp->deadLine = m_ptr->m1_i2;
  return(OK);
}



