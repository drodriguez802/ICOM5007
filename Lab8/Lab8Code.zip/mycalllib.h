#include<lib.h>
#include<unistd.h>
#include<stdlib.h>
PUBLIC int mycall (long i)
{
		
	message m;
	m.m1_i1 = i;
	printf("Long number received\n");
	return ( _syscall(PM_PROC_NR,MYCALL, &m) );
}