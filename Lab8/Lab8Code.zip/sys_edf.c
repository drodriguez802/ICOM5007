#include "syslib.h"

/*===========================================================================*
 *                                sys_edf				     *
 *===========================================================================*/
PUBLIC int sys_edf(int deadLine, endpoint_t endPoint)
{
  message m;
  m.m1_i2 = deadLine;
  m.m1_i3 = endPoint;
  return(_kernel_call(SYS_SCHEDEDF, &m));
}

