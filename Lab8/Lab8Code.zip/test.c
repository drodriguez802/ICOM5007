#include<mycalllib.h>
int main(void)
{
	mycall();
	return 0;
}